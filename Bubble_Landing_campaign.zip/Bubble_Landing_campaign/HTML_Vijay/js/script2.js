$('.your-class').slick({
    infinite: false,
    slidesToShow: 3,
    slidesToScroll:1,
    responsive:[  
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              infinite:true
            }
          }
    ]
  });