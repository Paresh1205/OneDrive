$(document).ready(function(){
	$('#myModal').modal('show');
	
	$("#modalform").validate({
    rules: {
      fname : {
        required: true,
        minlength: 3
      },
      lname: {
        required: true,
        minlength:3
      },
      email: {
        required: true,
        email: true
      }
    },
    messages : {
      fname: {
        required:"First Name is Required",
        minlength: "Name should be at least 3 characters"
      },
      lname: {
        required: "Last Name is required",
        minlength: "Name should be at least 3 characters"
      },
      email: {
        required:"Email is required",
        email: "The email should be in the format: abc@domain.tld"
      }
      
    }
  });
	
	
});





















